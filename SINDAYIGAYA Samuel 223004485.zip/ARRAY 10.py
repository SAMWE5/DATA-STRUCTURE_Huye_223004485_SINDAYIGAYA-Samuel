temperatures_3d = [
    [[22, 23, 24, 25, 26, 27, 28]],  # City 1
    [[20, 21, 22, 23, 24, 25, 26]],  # City 2
    [[18, 19, 20, 21, 22, 23, 24]],  # City 3
    [[30, 29, 31, 32, 33, 30, 31]],  # City 4
]
average_temperatures = [sum(city[0]) / len(city[0]) for city in temperatures_3d]
print("Average temperatures for each city:", average_temperatures)
