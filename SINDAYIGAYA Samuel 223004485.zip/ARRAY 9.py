marks = [
    [85, 90, 80],  # Student 1
    [78, 85, 88],  # Student 2
    [92, 91, 95]   # Student 3
]
total_marks = [sum(student) for student in marks]
print("Total marks of students:", total_marks)
