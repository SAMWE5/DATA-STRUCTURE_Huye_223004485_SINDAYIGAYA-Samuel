. to_do_list = ["buy groceries", "clean the house", "finish report"]
to_do_list.remove("clean the house")
print(to_do_list)  # Output: ['buy groceries', 'finish report']

