shopping_list = ["milk", "bread", "eggs", "butter"]
shopping_list.remove("butter")
print(shopping_list)  # Output: ['milk', 'bread', 'eggs']
