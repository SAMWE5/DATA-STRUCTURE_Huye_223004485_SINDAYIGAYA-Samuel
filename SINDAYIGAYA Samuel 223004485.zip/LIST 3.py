ages = [25, 32, 18, 40, 22]
ages.sort()
print(ages)  # Output: [18, 22, 25, 32, 40]
