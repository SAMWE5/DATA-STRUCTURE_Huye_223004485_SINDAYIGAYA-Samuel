stock_prices = [150.0, 155.5, 148.0, 160.25, 157.75, 162.0, 159.0]
max_price = max(stock_prices)
min_price = min(stock_prices)
print("Maximum stock price:", max_price)
print("Minimum stock price:", min_price)
