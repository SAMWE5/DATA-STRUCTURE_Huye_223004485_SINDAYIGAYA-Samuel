random_numbers = [12, 7, 3, 20, 15, 6, 11]
even_count = sum(1 for num in random_numbers if num % 2 == 0)
odd_count = sum(1 for num in random_numbers if num % 2 != 0)
print("Even numbers count:", even_count)
print("Odd numbers count:", odd_count)
