image = [
    [[255, 0, 0], [0, 255, 0]],
    [[0, 0, 255], [255, 255, 0]]  
]
inverted_image = [[[255 - channel for channel in pixel] for pixel in row] for row in image]

print("Inverted Image:")
for row in inverted_image:
    print(row)
