marks = [85, 90, 78, 92, 88]
reversed_marks = marks[::-1]
print("Reversed marks:", reversed_marks)
