board = [['X', 'O', 'X'],
         ['O', 'X', 'O'],
         ['O', 'X', 'X']]
def check_winner(b):
    for row in b:
        if row.count(row[0]) == len(row) and row[0] != '':
            return row[0]
    for col in range(len(b)):
        if all(b[row][col] == b[0][col] and b[0][col] != '' for row in range(len(b))):
            return b[0][col]
    if all(b[i][i] == b[0][0] and b[0][0] != '' for i in range(len(b))):
        return b[0][0]
    if all(b[i][len(b) - 1 - i] == b[0][len(b) - 1] and b[0][len(b) - 1] != '' for i in range(len(b))):
        return b[0][len(b) - 1]
    return None

winner = check_winner(board)
if winner:
    print("Winner:", winner)
else:
    print("No winner yet.")
