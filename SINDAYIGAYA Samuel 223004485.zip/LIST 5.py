 friends_list1 = ["John", "Sarah", "Mike"]
friends_list2 = ["Sarah", "David", "Alice"]
merged_friends = list(set(friends_list1 + friends_list2))
print(merged_friends)  # Output: ['Alice', 'Mike', 'David', 'John', 'Sarah']
