expenses = [
    [1200, 300, 150],  
    [1200, 350, 100],  
    [1200, 400, 200],  
    [1200, 320, 180],  
    [1200, 330, 150],  
    [1200, 310, 170]   
]
average_expenses = [sum(x) / len(expenses) for x in zip(*expenses)]
print(average_expenses)  # Output: [1200.0, 343.33, 161.67]
