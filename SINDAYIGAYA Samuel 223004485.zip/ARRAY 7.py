sales_data = [
    [200, 220, 210, 250, 300, 270, 290],  
    [150, 160, 165, 180, 175, 190, 200],  
    [300, 290, 310, 320, 330, 340, 350]   
]
for product_sales in sales_data:
    print(product_sales)
