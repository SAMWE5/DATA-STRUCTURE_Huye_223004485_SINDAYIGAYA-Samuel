attendees = ["Alice", "Bob", "Charlie"]
attendees.append("David")
print(attendees)  # Output: ['Alice', 'Bob', 'Charlie', 'David']
