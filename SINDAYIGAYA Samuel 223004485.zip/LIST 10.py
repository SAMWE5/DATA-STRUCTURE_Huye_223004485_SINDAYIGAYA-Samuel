 scores = [[90, 85, 78], [88, 92, 85], [70, 75, 80]]
averages = [sum(game) / len(game) for game in scores]
winner_index = averages.index(max(averages))
print(f"Winner is Player {winner_index + 1} with an average score of {averages[winner_index]:.2f}")  

