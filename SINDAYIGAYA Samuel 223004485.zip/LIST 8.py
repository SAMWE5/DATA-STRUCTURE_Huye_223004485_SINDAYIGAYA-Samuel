seating = [["A1", "A2", "A3"], ["B1", "B2", "B3"], ["C1", "C2", "C3"]]
seating[0][1] = "Reserved"  # Reserve seat A2
print(seating)  # Output: [['A1', 'Reserved', 'A3'], ['B1', 'B2', 'B3'], ['C1', 'C2', 'C3']]
