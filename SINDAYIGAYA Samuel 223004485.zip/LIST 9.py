products = [["Laptop", 1200, 10], ["Phone", 800, 0], ["Tablet", 500, 5]]
in_stock_products = [product for product in products if product[2] > 0]
print(in_stock_products)  # Output: [['Laptop', 1200, 10], ['Tablet', 500, 5]]
